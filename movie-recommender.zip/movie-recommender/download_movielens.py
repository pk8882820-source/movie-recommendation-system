"""Download real MovieLens (100k) data into data/ (same format as the sample files)."""
import urllib.request, zipfile, io, shutil, os
URL = "https://files.grouplens.org/datasets/movielens/ml-latest-small.zip"
z = zipfile.ZipFile(io.BytesIO(urllib.request.urlopen(URL).read()))
for name in ("movies.csv", "ratings.csv"):
    with z.open(f"ml-latest-small/{name}") as src, open(os.path.join("data", name), "wb") as dst:
        shutil.copyfileobj(src, dst)
print("MovieLens data saved to data/")
