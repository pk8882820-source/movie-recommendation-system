"""CLI:  python main.py --movie "Toy Story" --mode hybrid   |   python main.py --user 3"""
import argparse
from recommender import MovieRecommender

p = argparse.ArgumentParser(description="Movie recommender")
p.add_argument("--movies", default="data/movies.csv")
p.add_argument("--ratings", default="data/ratings.csv")
p.add_argument("--movie", help="Movie title (partial match ok)")
p.add_argument("--mode", choices=["content", "collab", "hybrid"], default="hybrid")
p.add_argument("--user", type=int, help="User ID for personalised recommendations")
p.add_argument("-n", type=int, default=10)
p.add_argument("--eval", action="store_true", help="Print hold-out RMSE")
a = p.parse_args()

rec = MovieRecommender(a.movies, a.ratings)
if a.eval:
    print(f"RMSE: {rec.evaluate_rmse():.3f}")
if a.movie:
    fn = {"content": rec.similar_by_content, "collab": rec.similar_by_ratings, "hybrid": rec.hybrid}[a.mode]
    print(f"\nBecause you liked '{a.movie}' ({a.mode}):\n", fn(a.movie, a.n).to_string(index=False))
if a.user:
    print(f"\nTop picks for user {a.user}:\n", rec.for_user(a.user, a.n).to_string(index=False))
