"""Movie recommendation engine: content-based, collaborative (SVD), and hybrid."""
import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class MovieRecommender:
    def __init__(self, movies_path="data/movies.csv", ratings_path="data/ratings.csv", n_factors=20):
        self.movies = pd.read_csv(movies_path).reset_index(drop=True)
        self.ratings = pd.read_csv(ratings_path)
        self.n_factors = n_factors
        self._build_content_model()
        self._build_collaborative_model()

    # ---------- Content-based: TF-IDF on genres ----------
    def _build_content_model(self):
        genres = self.movies["genres"].fillna("").str.replace("|", " ", regex=False)
        self.tfidf = TfidfVectorizer(token_pattern=r"[^\s]+").fit_transform(genres)

    # ---------- Collaborative: SVD matrix factorisation ----------
    def _build_collaborative_model(self):
        movie_idx = {m: i for i, m in enumerate(self.movies["movieId"])}
        r = self.ratings[self.ratings["movieId"].isin(movie_idx)].copy()
        self.user_ids = sorted(r["userId"].unique())
        self.user_idx = {u: i for i, u in enumerate(self.user_ids)}
        self.user_mean = r.groupby("userId")["rating"].mean()
        r["centered"] = r["rating"] - r["userId"].map(self.user_mean)
        rows = r["userId"].map(self.user_idx)
        cols = r["movieId"].map(movie_idx)
        self.matrix = csr_matrix((r["centered"], (rows, cols)),
                                 shape=(len(self.user_ids), len(self.movies)))
        k = max(2, min(self.n_factors, min(self.matrix.shape) - 1))
        svd = TruncatedSVD(n_components=k, random_state=42)
        self.user_factors = svd.fit_transform(self.matrix)
        self.item_factors = svd.components_.T
        self.rated = {u: set(g["movieId"]) for u, g in r.groupby("userId")}

    # ---------- Helpers ----------
    def find_movie(self, query):
        """Return row index of best title match (case-insensitive substring)."""
        mask = self.movies["title"].str.contains(query, case=False, regex=False)
        if not mask.any():
            raise ValueError(f"No movie found matching '{query}'")
        return self.movies[mask].index[0]

    def _top(self, scores, exclude, n):
        order = np.argsort(-scores)
        out = [i for i in order if i not in exclude][:n]
        res = self.movies.iloc[out][["title", "genres"]].copy()
        res["score"] = scores[out].round(3)
        return res.reset_index(drop=True)

    # ---------- Public API ----------
    def similar_by_content(self, title, n=10):
        i = self.find_movie(title)
        return self._top(cosine_similarity(self.tfidf[i], self.tfidf).ravel(), {i}, n)

    def similar_by_ratings(self, title, n=10):
        i = self.find_movie(title)
        return self._top(cosine_similarity(self.item_factors[i:i + 1], self.item_factors).ravel(), {i}, n)

    def hybrid(self, title, n=10, alpha=0.5):
        """alpha = weight on content similarity, (1-alpha) on rating similarity."""
        i = self.find_movie(title)
        c = cosine_similarity(self.tfidf[i], self.tfidf).ravel()
        s = cosine_similarity(self.item_factors[i:i + 1], self.item_factors).ravel()
        return self._top(alpha * c + (1 - alpha) * s, {i}, n)

    def for_user(self, user_id, n=10):
        if user_id not in self.user_idx:
            raise ValueError(f"Unknown user {user_id}")
        u = self.user_idx[user_id]
        scores = self.user_factors[u] @ self.item_factors.T + self.user_mean[user_id]
        seen = {i for i, m in enumerate(self.movies["movieId"]) if m in self.rated[user_id]}
        return self._top(np.clip(scores, 0, 5), seen, n)

    def evaluate_rmse(self, test_frac=0.2, seed=42):
        """Hold out part of the ratings, retrain, report RMSE."""
        import tempfile, os
        test = self.ratings.sample(frac=test_frac, random_state=seed)
        train = self.ratings.drop(test.index)
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "r.csv"); train.to_csv(p, index=False)
            m = MovieRecommender.__new__(MovieRecommender)
            m.movies, m.ratings, m.n_factors = self.movies, pd.read_csv(p), self.n_factors
            m._build_content_model(); m._build_collaborative_model()
        mid = {x: i for i, x in enumerate(self.movies["movieId"])}
        errs = []
        for row in test.itertuples():
            if row.userId in m.user_idx and row.movieId in mid:
                u, i = m.user_idx[row.userId], mid[row.movieId]
                pred = m.user_factors[u] @ m.item_factors[i] + m.user_mean[row.userId]
                errs.append((np.clip(pred, 0.5, 5) - row.rating) ** 2)
        return float(np.sqrt(np.mean(errs)))
