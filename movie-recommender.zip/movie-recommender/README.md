# 🎬 Movie Recommendation System

A Python movie recommender with three approaches, a CLI, and a Streamlit web app.

## Features
- **Content-based** – TF-IDF on genres, cosine similarity
- **Collaborative filtering** – SVD matrix factorisation on user ratings
- **Hybrid** – weighted blend of both
- **Personalised picks** for a user ID, plus hold-out **RMSE** evaluation
- Works offline with sample data; drop-in support for the real **MovieLens** dataset

## Setup
```bash
git clone https://github.com/<your-username>/movie-recommender.git
cd movie-recommender
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Usage
```bash
python main.py --movie "Toy Story" --mode hybrid -n 5   # similar movies (content | collab | hybrid)
python main.py --user 3                                  # personalised recommendations
python main.py --eval                                    # RMSE on held-out ratings
streamlit run app.py                                     # web UI
```

## Use real data (MovieLens, ~100k ratings)
```bash
python download_movielens.py
```
This overwrites `data/movies.csv` and `data/ratings.csv` with the real dataset.
Regenerate the synthetic sample with `python make_sample_data.py`.

## How it works
| Method | Idea |
|---|---|
| Content | Movies with similar genre vectors are similar |
| Collaborative | Users' mean-centred ratings are factorised (TruncatedSVD); movies with similar latent factors are similar, and `user · movie` factors predict a user's rating |
| Hybrid | `alpha * content + (1 - alpha) * collaborative` |

## Project structure
```
recommender.py          core engine
main.py                 command-line interface
app.py                  Streamlit app
download_movielens.py   fetch real data
make_sample_data.py     build offline sample data
data/                   movies.csv, ratings.csv
```

## Ideas to extend
Add tags/plot text to TF-IDF, use TMDB posters via API, try implicit ALS, add a Flask/FastAPI endpoint.

## License
MIT
