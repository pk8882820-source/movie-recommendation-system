"""Generate a small synthetic dataset so the project runs offline."""
import numpy as np, pandas as pd
movies = [
("Toy Story (1995)","Adventure|Animation|Children|Comedy"),("Finding Nemo (2003)","Adventure|Animation|Children|Comedy"),
("Shrek (2001)","Adventure|Animation|Children|Comedy|Fantasy"),("The Lion King (1994)","Adventure|Animation|Children|Drama"),
("Up (2009)","Adventure|Animation|Children|Drama"),("Inception (2010)","Action|Crime|Sci-Fi|Thriller"),
("The Matrix (1999)","Action|Sci-Fi|Thriller"),("Interstellar (2014)","Adventure|Drama|Sci-Fi"),
("Blade Runner (1982)","Action|Sci-Fi|Thriller"),("Avatar (2009)","Action|Adventure|Sci-Fi"),
("The Dark Knight (2008)","Action|Crime|Drama"),("Die Hard (1988)","Action|Crime|Thriller"),
("Mad Max: Fury Road (2015)","Action|Adventure|Sci-Fi"),("Gladiator (2000)","Action|Adventure|Drama"),
("The Godfather (1972)","Crime|Drama"),("Pulp Fiction (1994)","Comedy|Crime|Drama|Thriller"),
("Goodfellas (1990)","Crime|Drama"),("Se7en (1995)","Mystery|Thriller"),
("The Silence of the Lambs (1991)","Crime|Horror|Thriller"),("Titanic (1997)","Drama|Romance"),
("The Notebook (2004)","Drama|Romance"),("La La Land (2016)","Comedy|Drama|Musical|Romance"),
("Pride & Prejudice (2005)","Drama|Romance"),("Forrest Gump (1994)","Comedy|Drama|Romance|War"),
("The Shawshank Redemption (1994)","Crime|Drama"),("Superbad (2007)","Comedy"),
("The Hangover (2009)","Comedy"),("Bridesmaids (2011)","Comedy|Romance"),
("Get Out (2017)","Horror|Mystery|Thriller"),("The Conjuring (2013)","Horror|Mystery|Thriller"),
("Harry Potter and the Sorcerer's Stone (2001)","Adventure|Children|Fantasy"),
("The Lord of the Rings: The Fellowship of the Ring (2001)","Adventure|Fantasy"),
("Spirited Away (2001)","Adventure|Animation|Fantasy"),("Coco (2017)","Adventure|Animation|Children|Fantasy|Musical"),
("Parasite (2019)","Comedy|Drama|Thriller"),("Dangal (2016)","Action|Drama"),("3 Idiots (2009)","Comedy|Drama"),
("Lagaan (2001)","Drama|Musical"),("Zindagi Na Milegi Dobara (2011)","Adventure|Comedy|Drama|Romance"),
("Dil Chahta Hai (2001)","Comedy|Drama|Romance"),
]
df = pd.DataFrame(movies, columns=["title","genres"]); df.insert(0,"movieId",range(1,len(df)+1))
df.to_csv("data/movies.csv", index=False)
rng = np.random.default_rng(42)
all_g = sorted({g for s in df.genres for g in s.split("|")})
rows = []
for u in range(1, 81):
    pref = {g: rng.normal(0, 1) for g in all_g}
    for m in rng.choice(df.movieId, size=rng.integers(10, 25), replace=False):
        gs = df.loc[df.movieId==m, "genres"].iloc[0].split("|")
        s = 3.2 + np.mean([pref[g] for g in gs]) * 0.9 + rng.normal(0, 0.4)
        rows.append((u, m, float(np.clip(round(s*2)/2, 0.5, 5)), 0))
pd.DataFrame(rows, columns=["userId","movieId","rating","timestamp"]).to_csv("data/ratings.csv", index=False)
print("Sample data written:", len(df), "movies,", len(rows), "ratings")
