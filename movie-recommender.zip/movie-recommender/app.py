"""Streamlit web UI:  streamlit run app.py"""
import streamlit as st
from recommender import MovieRecommender

st.set_page_config(page_title="Movie Recommender", page_icon="🎬")
st.title("🎬 Movie Recommendation System")

@st.cache_resource
def load():
    return MovieRecommender("data/movies.csv", "data/ratings.csv")

rec = load()
mode = st.sidebar.radio("Recommend by", ["Similar movie", "User profile"])
n = st.sidebar.slider("How many?", 5, 20, 10)

if mode == "Similar movie":
    title = st.selectbox("Pick a movie you like", rec.movies["title"].tolist())
    method = st.radio("Method", ["Hybrid", "Content (genres)", "Collaborative (ratings)"], horizontal=True)
    if st.button("Recommend"):
        fn = {"Hybrid": rec.hybrid, "Content (genres)": rec.similar_by_content,
              "Collaborative (ratings)": rec.similar_by_ratings}[method]
        st.dataframe(fn(title, n), use_container_width=True)
else:
    uid = st.selectbox("User ID", rec.user_ids)
    if st.button("Recommend"):
        st.dataframe(rec.for_user(uid, n), use_container_width=True)
